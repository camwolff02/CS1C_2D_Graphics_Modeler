var searchData=
[
  ['canvas_0',['Canvas',['../class_canvas.html#a5525075d65b32480dd518d382946e0ea',1,'Canvas']]],
  ['capacity_1',['capacity',['../classmy_std_1_1vector.html#a3a84d877c0808556734d2e012f8bbdaf',1,'myStd::vector']]]
];
