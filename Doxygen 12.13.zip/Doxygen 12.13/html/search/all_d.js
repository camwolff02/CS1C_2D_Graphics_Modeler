var searchData=
[
  ['text_0',['Text',['../classmy_std_1_1_text.html',1,'myStd::Text'],['../classmy_std_1_1_text.html#a95ea223cb13ddc43a56ccc4530a23275',1,'myStd::Text::Text()']]]
];
