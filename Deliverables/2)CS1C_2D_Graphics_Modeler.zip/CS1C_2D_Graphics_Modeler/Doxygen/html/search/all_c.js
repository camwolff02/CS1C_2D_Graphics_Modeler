var searchData=
[
  ['setbrush_0',['setBrush',['../class_shape.html#aee7defb916cf41a4de384bae1e8c501b',1,'Shape']]],
  ['setid_1',['setId',['../class_shape.html#a96fcff5389f4e35805e72d075464eeaa',1,'Shape']]],
  ['setpen_2',['setPen',['../class_shape.html#afc6ab66540293c5187aaad4ce1a09ac6',1,'Shape']]],
  ['setshapetype_3',['setShapeType',['../class_shape.html#a05fc5c8506a62f2eb43fbf29818b4258',1,'Shape']]],
  ['shape_4',['Shape',['../class_shape.html',1,'Shape'],['../class_shape.html#a5aa64acb18f0bcfd109506f7dd2ceb47',1,'Shape::Shape(QPainter *painterPTR, ShapeType type, int id)'],['../class_shape.html#a5a7ba966cf5efb6745a9b15dc63afd7f',1,'Shape::Shape(const Shape &amp;rhs)=delete']]],
  ['shape_2ecpp_5',['shape.cpp',['../shape_8cpp.html',1,'']]],
  ['shape_2eh_6',['shape.h',['../shape_8h.html',1,'']]],
  ['shapes_2eh_7',['shapes.h',['../shapes_8h.html',1,'']]],
  ['shapetype_8',['ShapeType',['../shape_8h.html#a5a4538eeab397888d88a4eefcc5a1345',1,'shape.h']]],
  ['size_9',['size',['../classmy_std_1_1vector.html#a72c4cf7716f3fb1db42b8cdc2347ef49',1,'myStd::vector']]],
  ['square_10',['Square',['../shape_8h.html#a5a4538eeab397888d88a4eefcc5a1345a1abc09cb455486ade0f6353591699809',1,'shape.h']]]
];
