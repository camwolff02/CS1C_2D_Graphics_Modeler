var searchData=
[
  ['text_0',['Text',['../classmy_std_1_1_text.html',1,'myStd::Text'],['../classmy_std_1_1_text.html#ad21677a8878136eb336ce5b08fa98c80',1,'myStd::Text::Text()'],['../shape_8h.html#a5a4538eeab397888d88a4eefcc5a1345a35d0dd9a40755601b657244976bfc14b',1,'Text():&#160;shape.h']]],
  ['text_2ecpp_1',['text.cpp',['../text_8cpp.html',1,'']]],
  ['text_2eh_2',['text.h',['../text_8h.html',1,'']]]
];
