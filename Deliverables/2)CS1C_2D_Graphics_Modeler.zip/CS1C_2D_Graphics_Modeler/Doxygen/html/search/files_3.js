var searchData=
[
  ['globals_2ecpp_0',['globals.cpp',['../globals_8cpp.html',1,'']]],
  ['globals_2eh_1',['globals.h',['../globals_8h.html',1,'']]]
];
