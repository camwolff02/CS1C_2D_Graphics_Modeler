var searchData=
[
  ['setbrush_0',['setBrush',['../class_shape.html#ac5aa170455b074fec2079b17840ddba7',1,'Shape']]],
  ['setid_1',['setId',['../class_shape.html#a96fcff5389f4e35805e72d075464eeaa',1,'Shape']]],
  ['setpen_2',['setPen',['../class_shape.html#a028e8f42ef5aaa8c3cbf004ab9076f2f',1,'Shape']]],
  ['setshapetype_3',['setShapeType',['../class_shape.html#a05fc5c8506a62f2eb43fbf29818b4258',1,'Shape']]],
  ['setx_4',['setX',['../class_shape.html#a2d8fd6861bf7906e0152a699ce6054c8',1,'Shape']]],
  ['sety_5',['setY',['../class_shape.html#aa2b8845b186bf95781ca5d5e22316343',1,'Shape']]],
  ['shape_6',['Shape',['../class_shape.html',1,'Shape'],['../class_shape.html#a2be57e345217494a0cdd999ea9e77da4',1,'Shape::Shape(ShapeType type, int id)'],['../class_shape.html#a5a7ba966cf5efb6745a9b15dc63afd7f',1,'Shape::Shape(const Shape &amp;rhs)=delete']]]
];
