var searchData=
[
  ['addelllipse_0',['addElllipse',['../classadd_elllipse.html#ac4403a3e6036cc093460d72cc8bca810',1,'addElllipse']]],
  ['addlines_1',['addLines',['../classadd_lines.html#a960b35c5e2dcfb92128bb331af5c24fa',1,'addLines']]],
  ['addpoint_2',['addPoint',['../classmy_std_1_1_polygon.html#a754eebc9520821f9d7f0923410260f85',1,'myStd::Polygon']]],
  ['addpolygon_3',['addPolygon',['../classadd_polygon.html#a3443e64e1557ef31386f1cdcf6bafc1b',1,'addPolygon']]],
  ['addpolyline_4',['addPolyline',['../classadd_polyline.html#a47e0c1b12f7b15ef403c158b4fe9c556',1,'addPolyline']]],
  ['addrectangles_5',['addRectangles',['../classadd_rectangles.html#a880a5c71ecbe58a62183c856e3c64977',1,'addRectangles']]],
  ['addshape_6',['addShape',['../class_canvas.html#a67dd4de2d248435c5b458bca17d1f574',1,'Canvas']]],
  ['addtextbox_7',['addTextBox',['../classadd_text_box.html#abe62bde091709c35e157c5d3c4df7aff',1,'addTextBox']]]
];
