var searchData=
[
  ['text_0',['Text',['../classmy_std_1_1_text.html',1,'myStd']]]
];
