var searchData=
[
  ['line_0',['Line',['../classmy_std_1_1_line.html#a4d5a3257ee87d35825d709a638c8493d',1,'myStd::Line::Line(int id=-1, int x1=0, int y1=0, int x2=0, int y2=0)'],['../classmy_std_1_1_line.html#a58d33d0a60925da91ee5a718bcc5749c',1,'myStd::Line::Line(Line &amp;&amp;)=default']]]
];
