var searchData=
[
  ['rectangle_0',['Rectangle',['../classmy_std_1_1_rectangle.html#a461c65c61a67d76de00bf5df9b0cdf97',1,'myStd::Rectangle::Rectangle(int id=-1, int x=0, int y=0, int width=0, int height=0)'],['../classmy_std_1_1_rectangle.html#ab3ef1dbc3b4b17f4f7c2f15714790fcc',1,'myStd::Rectangle::Rectangle(Rectangle &amp;&amp;)=default']]],
  ['reserve_1',['reserve',['../classmy_std_1_1vector.html#a50e786a02a59e689999365037ae26b3a',1,'myStd::vector']]],
  ['resetshapecount_2',['resetShapeCount',['../class_shape.html#a7ce5090298133856826690aab427c8a2',1,'Shape']]],
  ['resize_3',['resize',['../classmy_std_1_1vector.html#aa54bd9c3d8d3b6191d7eb7f85490eadb',1,'myStd::vector']]]
];
