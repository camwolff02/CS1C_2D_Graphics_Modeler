# CS1C_2D_Graphics_Modeler
Saddleback Computer Science 1C Class Project, simple 2D graphics modeler implemented using Qt for UI
