var searchData=
[
  ['text_0',['Text',['../shape_8h.html#a5a4538eeab397888d88a4eefcc5a1345a35d0dd9a40755601b657244976bfc14b',1,'shape.h']]]
];
