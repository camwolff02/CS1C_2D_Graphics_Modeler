var searchData=
[
  ['isadmin_0',['isAdmin',['../globals_8cpp.html#a0fe6cb22a7f2a089358e90fe82fa6363',1,'isAdmin():&#160;globals.cpp'],['../globals_8h.html#a0fe6cb22a7f2a089358e90fe82fa6363',1,'isAdmin():&#160;globals.cpp']]]
];
