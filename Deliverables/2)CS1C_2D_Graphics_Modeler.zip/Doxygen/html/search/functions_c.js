var searchData=
[
  ['setbrush_0',['setBrush',['../class_shape.html#aee7defb916cf41a4de384bae1e8c501b',1,'Shape']]],
  ['setid_1',['setId',['../class_shape.html#a96fcff5389f4e35805e72d075464eeaa',1,'Shape']]],
  ['setpen_2',['setPen',['../class_shape.html#afc6ab66540293c5187aaad4ce1a09ac6',1,'Shape']]],
  ['setshapetype_3',['setShapeType',['../class_shape.html#a05fc5c8506a62f2eb43fbf29818b4258',1,'Shape']]],
  ['shape_4',['Shape',['../class_shape.html#a5aa64acb18f0bcfd109506f7dd2ceb47',1,'Shape::Shape(QPainter *painterPTR, ShapeType type, int id)'],['../class_shape.html#a5a7ba966cf5efb6745a9b15dc63afd7f',1,'Shape::Shape(const Shape &amp;rhs)=delete']]],
  ['size_5',['size',['../classmy_std_1_1vector.html#a72c4cf7716f3fb1db42b8cdc2347ef49',1,'myStd::vector']]]
];
