var searchData=
[
  ['text_0',['Text',['../classmy_std_1_1_text.html#ad21677a8878136eb336ce5b08fa98c80',1,'myStd::Text']]]
];
