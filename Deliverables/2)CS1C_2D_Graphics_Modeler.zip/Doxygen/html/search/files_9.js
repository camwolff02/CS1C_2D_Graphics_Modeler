var searchData=
[
  ['text_2ecpp_0',['text.cpp',['../text_8cpp.html',1,'']]],
  ['text_2eh_1',['text.h',['../text_8h.html',1,'']]]
];
