#include "globals.h"

// GLOBAL DEFINITIONS GO HERE

bool isAdmin = false;

// in any file we need to use this global var / any other global vars
// include "globals.h" in the file
